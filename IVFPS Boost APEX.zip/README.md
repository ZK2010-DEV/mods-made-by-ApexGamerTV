# IVPerformanceBooster (GTA IV)
**AI-made, code-only** performance booster for GTA IV that **does not change any graphics settings**.  
It focuses on process/thread scheduling, timer resolution, OS cache priming, and stability for smoother frametimes on low-end PCs.

> Works with GTA IV Complete Edition (Steam/Rockstar). Pure DLL; no graphics changes.

## What it does
- Sets **high process priority** and raises all game **thread priorities** to reduce stalls.
- Applies a balanced **CPU affinity** (prefers even logical cores) to reduce SMT contention on older CPUs.
- Sets **1ms timer resolution** for better frame pacing.
- **Primes disk cache** for `.img`/`.rpf` archives (up to 32MB per file) to cut early hitching.
- Requests a slightly larger **working set** from Windows (harmless hint).

None of these alter your graphics options, resolution, textures, or draw distances.

## Build (Windows)
### Option A — Visual Studio via CMake
1. Install **Visual Studio 2022** Desktop Development with C++.
2. Open a **x86 Native Tools** command prompt.
3. Run:
   ```bat
   cd IVPerformanceBooster
   cmake -S . -B build -A Win32
   cmake --build build --config Release
   ```
4. Get `build\Release\IVPerformanceBooster.dll` and rename it to **IVPerformanceBooster.asi**.

### Option B — MinGW (Win32)
```bat
cd IVPerformanceBooster
cmake -S . -B build
cmake --build build --config Release
```

## Install
1. Ensure you have an **ASI loader** (e.g., `dinput8.dll`) in your GTA IV folder. If you already use ScriptHook/ASI mods, you likely have one.
2. Copy **IVPerformanceBooster.asi** into your **GTA IV game directory** (same folder as `GTAIV.exe`).  
3. (Optional) Create `commandline.txt` next to `GTAIV.exe` and paste the template below.

## Optional: `commandline.txt` template (no visual downgrades)
These engine flags do **not** directly lower visual settings; they mainly remove internal caps and reduce artificial limits:
```
-norestrictions
-nomemrestrict
-noprecache
-percentvidmem 100
-availablevidmem 100.0
-reserve 0
```
> If any flag causes instability on your machine, just remove that line. They don't change visible quality.

## Uninstall
Delete `IVPerformanceBooster.asi` and the log file `IVPerformanceBooster.log`.

## Notes & Limits (honest expectations)
- GTA IV is **DX9-era and CPU-bound**; extreme “potato PCs” may still struggle at *ultra* settings. This mod avoids touching graphics and focuses on **frametime stability** and **loading hitches**.
- No game files are modified. No graphics options are touched.
- Safe-by-design: if anything fails, the game still runs normally.

## Changelog
- v1.0 — Initial release.
