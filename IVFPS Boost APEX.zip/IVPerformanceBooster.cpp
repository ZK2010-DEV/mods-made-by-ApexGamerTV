// IVPerformanceBooster - AI-made FPS/PERF booster for GTA IV
// Does NOT modify graphics settings. Focuses on process/thread scheduling, timer resolution, and IO cache priming.
// Build: DLL (x86). Rename to "IVPerformanceBooster.asi" and drop into GTA IV root with an ASI loader.
// Author: AI-generated for the user
#define _WIN32_WINNT 0x0600
#include <windows.h>
#include <tlhelp32.h>
#include <shlwapi.h>
#include <vector>
#include <string>
#include <fstream>

#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "winmm.lib")

static HMODULE g_hModule = NULL;
static wchar_t g_gameDir[MAX_PATH] = L"";

static void log(const std::wstring& msg) {
    wchar_t path[MAX_PATH];
    wsprintfW(path, L"%s\\IVPerformanceBooster.log", g_gameDir[0] ? g_gameDir : L".");
    std::wofstream f(path, std::ios::app);
    if (f) {
        SYSTEMTIME st; GetLocalTime(&st);
        f << L"[" << st.wYear << L"-" << st.wMonth << L"-" << st.wDay << L" "
          << st.wHour << L":" << st.wMinute << L":" << st.wSecond << L"] " << msg << L"\n";
    }
}

static void set_timer_resolution() {
    TIMECAPS tc{};
    if (timeGetDevCaps(&tc, sizeof(tc)) == TIMERR_NOERROR) {
        timeBeginPeriod(tc.wPeriodMin);
        log(L"Timer resolution set to minimum via timeBeginPeriod().");
    } else {
        timeBeginPeriod(1);
        log(L"Timer resolution set to 1ms fallback.");
    }
}

static void elevate_process_priority() {
    if (SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS)) {
        log(L"Process priority set to HIGH_PRIORITY_CLASS.");
    } else {
        log(L"Failed to set process priority.");
    }
}

static DWORD_PTR build_affinity_mask(bool prefer_even) {
    SYSTEM_INFO si{}; GetSystemInfo(&si);
    DWORD_PTR mask = 0;
    for (DWORD i = 0; i < si.dwNumberOfProcessors && i < (sizeof(DWORD_PTR) * 8); ++i) {
        bool pick = prefer_even ? (i % 2 == 0) : true;
        if (pick) mask |= (DWORD_PTR(1) << i);
    }
    return mask ? mask : (DWORD_PTR)~0ULL;
}

static void apply_affinity() {
    // Prefer even-numbered logical cores to reduce SMT contention on some CPUs.
    DWORD_PTR mask = build_affinity_mask(true);
    DWORD_PTR prev=0;
    if (SetProcessAffinityMask(GetCurrentProcess(), mask)) {
        log(L"Applied process CPU affinity (prefer even-numbered cores).");
    } else {
        log(L"Failed to set process affinity.");
    }
    // Elevate all threads to above normal to reduce stalls in main/game/render threads
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snap != INVALID_HANDLE_VALUE) {
        DWORD pid = GetCurrentProcessId();
        THREADENTRY32 te{}; te.dwSize = sizeof(te);
        if (Thread32First(snap, &te)) {
            do {
                if (te.th32OwnerProcessID == pid) {
                    HANDLE th = OpenThread(THREAD_SET_INFORMATION | THREAD_QUERY_INFORMATION, FALSE, te.th32ThreadID);
                    if (th) {
                        SetThreadPriority(th, THREAD_PRIORITY_ABOVE_NORMAL);
                        SetThreadIdealProcessor(th, MAXIMUM_PROCESSORS);
                        CloseHandle(th);
                    }
                }
            } while (Thread32Next(snap, &te));
        }
        CloseHandle(snap);
        log(L"Raised thread priorities to ABOVE_NORMAL and set ideal processor hints.");
    }
}

static void warm_up_disk_cache() {
    // Prime OS cache for big game archives to reduce first-minute stutter.
    // We read small chunks from *.img and *.rpf without retaining memory.
    const wchar_t* exts[] = { L"*.img", L"*.rpf" };
    for (auto ext : exts) {
        wchar_t pattern[MAX_PATH];
        wsprintfW(pattern, L"%s\\%s", g_gameDir, ext);
        WIN32_FIND_DATAW fd{};
        HANDLE hFind = FindFirstFileW(pattern, &fd);
        if (hFind == INVALID_HANDLE_VALUE) continue;
        do {
            if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
                wchar_t fpath[MAX_PATH];
                wsprintfW(fpath, L"%s\\%s", g_gameDir, fd.cFileName);
                HANDLE h = CreateFileW(fpath, GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
                if (h != INVALID_HANDLE_VALUE) {
                    const DWORD chunk = 1 << 20; // 1 MiB
                    std::vector<char> buf(chunk);
                    DWORD read=0; LARGE_INTEGER size{}; GetFileSizeEx(h, &size);
                    LONGLONG toRead = size.QuadPart < (32LL<<20) ? size.QuadPart : (32LL<<20); // up to 32MB per file
                    LONGLONG total=0;
                    while (total < toRead) {
                        if (!ReadFile(h, buf.data(), chunk, &read, NULL) || read==0) break;
                        total += read;
                        SetFilePointer(h, (LONG)total, NULL, FILE_BEGIN);
                    }
                    CloseHandle(h);
                }
            }
        } while (FindNextFileW(hFind, &fd));
        FindClose(hFind);
    }
    log(L"Primed OS cache for *.img/*.rpf archives (up to 32MB each).");
}

static void expand_working_set() {
    SIZE_T minWS=64<<20, maxWS=0; // request 64MB min; leave max unchanged
    if (SetProcessWorkingSetSize(GetCurrentProcess(), minWS, maxWS)) {
        log(L"Requested larger minimum working set (64MB).");
    } else {
        log(L"Working set size request not granted (non-fatal).");
    }
}

static DWORD WINAPI main_thread(LPVOID) {
    // Determine game directory from module path
    wchar_t modPath[MAX_PATH]; GetModuleFileNameW(NULL, modPath, MAX_PATH);
    lstrcpyW(g_gameDir, modPath);
    PathRemoveFileSpecW(g_gameDir);

    log(L"IVPerformanceBooster initializing...");
    set_timer_resolution();
    elevate_process_priority();
    apply_affinity();
    expand_working_set();
    warm_up_disk_cache();
    log(L"IVPerformanceBooster ready. Enjoy smoother frametimes without touching graphics settings.");
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID) {
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        g_hModule = hModule;
        DisableThreadLibraryCalls(hModule);
        HANDLE h = CreateThread(NULL, 0, main_thread, NULL, 0, NULL);
        if (h) CloseHandle(h);
    } else if (ul_reason_for_call == DLL_PROCESS_DETACH) {
        // nothing
    }
    return TRUE;
}
